<?php
/**
 * Renders the site's tracking pixels (Meta Pixel / GTM / gtag) directly into
 * the page, exactly like render_landing.php does.
 *
 * Previously this injected the pixel via JavaScript after requestIdleCallback
 * (up to 4s after load). That made Meta's Pixel Helper / Events Manager / domain
 * checks miss the pixel, lost PageViews for visitors who left early, and meant
 * fbq() did not exist yet when inline events (Purchase, AddToCart...) ran.
 *
 * The Meta base code is already asynchronous (fbevents.js is loaded with
 * t.async = true), so printing it inline costs nothing in render performance.
 *
 * Usage (includes/header.php):
 *   in <head>:        echo renderDeferredPixelLoader($siteSettings);
 *   after <body>:     echo renderPixelBody($siteSettings);
 */
function renderDeferredPixelLoader($siteSettings) {
    $head = $siteSettings['pixel_head'] ?? '';
    if (trim($head) === '') {
        return '';
    }

    // Safe helper: queues events through fbq's stub even before fbevents.js has
    // loaded, and never throws if the pixel is blocked (ad-blockers etc.).
    $helper = <<<'JS'
<script>
window.trackPixel = function (event, params, opts) {
    try {
        if (typeof window.fbq === 'function') {
            if (opts) { fbq('track', event, params || {}, opts); }
            else { fbq('track', event, params || {}); }
        }
    } catch (e) {}
};
</script>
JS;

    return "<!-- @head pixel -->\n" . $head . "\n" . $helper . "\n";
}

function renderPixelBody($siteSettings) {
    $body = $siteSettings['pixel_body'] ?? '';
    if (trim($body) === '') {
        return '';
    }
    return "<!-- @body pixel -->\n" . $body . "\n";
}

<?php
/**
 * Renders the site's tracking pixels (Meta Pixel / Google Tag Manager / gtag)
 * wrapped in a loader that defers them until the browser is idle, so they
 * don't compete with the initial page render on the main storefront pages
 * (home, category, product, cart, checkout, search — anywhere that includes
 * includes/header.php).
 *
 * NOTE: this file was missing from the project when this round of fixes
 * started (nothing in includes/ or admin/includes/ defined it) and every
 * page using includes/header.php was fatal-erroring as a result. This is a
 * reconstruction, not a recovered original — it reads the same pixel_head /
 * pixel_body fields from settings.json that the admin "Pixel & Tracking"
 * screen (admin/pixel.php) already manages and that render_landing.php
 * already echoes directly (immediately, unde-ferred, since ad-platform
 * attribution on a paid landing page needs the pixel to fire right away).
 * Here, for the general site, the same markup is injected after the page
 * is idle (or on window load as a fallback) instead of blocking render.
 *
 * Verify tracking still fires as expected (GTM Preview mode / Meta Pixel
 * Helper) after deploying this.
 *
 * @param array $siteSettings Decoded settings.json
 * @return string A single <script> block to echo into <head>. Empty string
 *                if no pixel codes are configured.
 */
function renderDeferredPixelLoader($siteSettings) {
    $head = $siteSettings['pixel_head'] ?? '';
    $body = $siteSettings['pixel_body'] ?? '';

    if (trim($head) === '' && trim($body) === '') {
        return '';
    }

    $payload = json_encode([
        'head' => $head,
        'body' => $body,
    ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);

    return <<<HTML
<script>
(function () {
    var pixelPayload = {$payload};
    var injected = false;

    function runScripts(nodes) {
        // Elements created via innerHTML never execute <script> tags, so each
        // one is rebuilt and re-appended to actually run (needed by both the
        // Meta Pixel and GTM snippets, which look for the first <script> on
        // the page to insert themselves next to). Only the specific nodes we
        // just inserted are touched here — never re-scan the whole head/body,
        // or pre-existing page scripts (e.g. footer.php's CLS tracker) get
        // re-executed and can throw on redeclaring their own top-level vars.
        for (var i = 0; i < nodes.length; i++) {
            var old = nodes[i];
            if (old.tagName !== 'SCRIPT') continue;
            var fresh = document.createElement('script');
            for (var a = 0; a < old.attributes.length; a++) {
                fresh.setAttribute(old.attributes[a].name, old.attributes[a].value);
            }
            fresh.textContent = old.textContent;
            old.parentNode.replaceChild(fresh, old);
        }
    }

    function injectPixels() {
        if (injected) return;
        injected = true;

        if (pixelPayload.head) {
            var headWrap = document.createElement('div');
            headWrap.innerHTML = pixelPayload.head;
            var headNodes = Array.prototype.slice.call(headWrap.childNodes);
            for (var h = 0; h < headNodes.length; h++) {
                document.head.appendChild(headNodes[h]);
            }
            runScripts(headNodes);
        }

        if (pixelPayload.body) {
            var bodyWrap = document.createElement('div');
            bodyWrap.innerHTML = pixelPayload.body;
            var bodyNodes = Array.prototype.slice.call(bodyWrap.childNodes);
            var ref = document.body.firstChild;
            for (var b = 0; b < bodyNodes.length; b++) {
                document.body.insertBefore(bodyNodes[b], ref);
            }
            runScripts(bodyNodes);
        }
    }

    if ('requestIdleCallback' in window) {
        requestIdleCallback(injectPixels, { timeout: 4000 });
    } else {
        window.addEventListener('load', function () {
            setTimeout(injectPixels, 0);
        });
    }
})();
</script>
HTML;
}

"# thirstybd" 
